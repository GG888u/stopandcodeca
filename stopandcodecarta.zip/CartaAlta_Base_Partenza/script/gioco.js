var buttonTag;
var messaggio;
var card;

buttonTag = document.getElementById("gioca");
messaggio = document.getElementById("messaggio");
card = document.getElementById("card");




buttonTag.onclick = function(){
    var cartaNumber;
    var cartaNumber2;
    var vincita;
    var perdita;
    var parita;
    var number2; var number;

    cartaNumber = document.getElementById("number");
    cartaNumber2 = document.getElementById("number2");

    
    number2 = Math.floor(Math.random() * 10)+1;
    number = Math.floor(Math.random() *10)+ 1;
    vincita = "complimenti, hai vinto!!"
    perdita = "mi dispiace, hai perso : ("
    parita = "parità"
    
    cartaNumber.innerHTML = number;
    cartaNumber2.innerHTML = number2;
    console.log(number);
    console.log(number2);

    if(number > number2){
          messaggio.innerHTML = vincita;
          
    } else if(number < number2){
        messaggio.innerHTML = perdita;
    }
    else{
        messaggio.innerHTML = parita;
    }




}



